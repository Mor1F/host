import mysql.connector
from mysql.connector import Error
from config import DB_CONFIG

class DatabaseManager:
    def __init__(self):
        try:
            self.conn = mysql.connector.connect(**DB_CONFIG)
            self.cur = self.conn.cursor()
            self.create_database()
            self.create_tables()
        except Error as e:
            print("Ошибка подключения к базе:", e)

    def create_database(self):
        self.cur.execute(f"CREATE DATABASE IF NOT EXISTS {DB_CONFIG['database']} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
        self.conn.database = DB_CONFIG['database']

    def create_tables(self):
        self.cur.execute("""
            CREATE TABLE IF NOT EXISTS library (
                id INT AUTO_INCREMENT PRIMARY KEY,
                название VARCHAR(255),
                автор VARCHAR(255),
                год INT,
                цена DECIMAL(10,2)
            )
        """)
        self.cur.execute("""
            CREATE TABLE IF NOT EXISTS publisher (
                id INT AUTO_INCREMENT PRIMARY KEY,
                название VARCHAR(255),
                автор VARCHAR(255),
                издатель VARCHAR(255)
            )
        """)
        self.conn.commit()

    def get_columns(self, table):
        self.cur.execute(f"DESCRIBE {table}")
        return [col[0] for col in self.cur.fetchall()]

    def get_all(self, table):
        self.cur.execute(f"SELECT * FROM {table}")
        return self.cur.fetchall()

    def add_record(self, table, values):
        columns = self.get_columns(table)[1:]
        placeholders = ", ".join(["%s"] * len(values))
        sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({placeholders})"
        self.cur.execute(sql, values)
        self.conn.commit()

    def delete_record(self, table, record_id):
        self.cur.execute(f"DELETE FROM {table} WHERE id = %s", (record_id,))
        self.conn.commit()

    def close(self):
        self.cur.close()
        self.conn.close()
