import pandas as pd
from db_manager import DatabaseManager

def export_to_excel(path, table):
    db = DatabaseManager()
    data = db.get_all(table)
    columns = db.get_columns(table)
    df = pd.DataFrame(data, columns=columns)
    df.to_excel(path, index=False)
    db.close()

def import_from_excel(path, table):
    db = DatabaseManager()
    df = pd.read_excel(path)
    db.cur.execute(f"DELETE FROM {table}")
    for _, row in df.iterrows():
        values = list(row)[1:]
        db.add_record(table, values)
    db.close()
