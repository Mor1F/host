DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "1234",
    "database": "library_app"
}
