import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from db_manager import DatabaseManager
from excel_utils import export_to_excel, import_from_excel

class TableWindow:
    def __init__(self, root, table_name):
        self.root = root
        self.table_name = table_name
        self.db = DatabaseManager()
        self.root.title(f"Таблица: {table_name}")

        btn_frame = tk.Frame(root)
        btn_frame.pack(fill=tk.X, pady=5)
        tk.Button(btn_frame, text="Добавить", command=self.add_record).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Удалить", command=self.delete_record).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Импорт Excel", command=self.import_excel).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Экспорт Excel", command=self.export_excel).pack(side=tk.LEFT, padx=5)

        columns = self.db.get_columns(table_name)
        self.tree = ttk.Treeview(root, columns=columns, show="headings")
        for col in columns:
            self.tree.heading(col, text=col)
        self.tree.pack(fill=tk.BOTH, expand=True)

        self.refresh_table()

    def refresh_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for record in self.db.get_all(self.table_name):
            self.tree.insert("", tk.END, values=record)

    def add_record(self):
        new = simpledialog.askstring("Добавить", "Введите значения через запятую:")
        if not new:
            return
        values = [v.strip() for v in new.split(",")]
        self.db.add_record(self.table_name, values)
        self.refresh_table()

    def delete_record(self):
        selected = self.tree.selection()
        if not selected:
            return
        record_id = self.tree.item(selected[0])["values"][0]
        self.db.delete_record(self.table_name, record_id)
        self.refresh_table()

    def import_excel(self):
        path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
        if path:
            import_from_excel(path, self.table_name)
            self.refresh_table()

    def export_excel(self):
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])
        if path:
            export_to_excel(path, self.table_name)
            messagebox.showinfo("Экспорт", "Данные успешно экспортированы!")
