import tkinter as tk
from table_window import TableWindow

class TableSelector:
    def __init__(self, root):
        self.root = root
        self.root.title("Выбор таблицы")

        tk.Label(root, text="Выберите таблицу:").pack(pady=10)
        tk.Button(root, text="Библиотека", command=lambda: self.open_table("library")).pack(pady=5)
        tk.Button(root, text="Издатель", command=lambda: self.open_table("publisher")).pack(pady=5)

    def open_table(self, table_name):
        self.root.destroy()
        new_root = tk.Tk()
        TableWindow(new_root, table_name)
        new_root.mainloop()
