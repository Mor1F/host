import tkinter as tk
from tkinter import messagebox
from table_selector import TableSelector

class LoginWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Авторизация")

        tk.Label(root, text="Логин:").grid(row=0, column=0)
        self.login_entry = tk.Entry(root)
        self.login_entry.grid(row=0, column=1)

        tk.Label(root, text="Пароль:").grid(row=1, column=0)
        self.pass_entry = tk.Entry(root, show="*")
        self.pass_entry.grid(row=1, column=1)

        tk.Button(root, text="Войти", command=self.check_login).grid(row=2, column=0, columnspan=2, pady=10)

    def check_login(self):
        login = self.login_entry.get()
        password = self.pass_entry.get()
        if login == "admin" and password == "1234":
            self.root.destroy()
            new_root = tk.Tk()
            TableSelector(new_root)
            new_root.mainloop()
        else:
            messagebox.showerror("Ошибка", "Неверный логин или пароль")
