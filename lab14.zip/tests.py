
from solution import *
import time, statistics, copy, json

def measure(alg_name, gen_fn, n, m, runs=5):
    alg = ALGORITHMS[alg_name]
    times = []
    for _ in range(runs):
        mat = gen_fn(n,m)
        # copy to avoid side effects
        start = time.perf_counter()
        _ = full_sort_pipeline(mat, alg)
        end = time.perf_counter()
        times.append(end-start)
    return statistics.mean(times), statistics.stdev(times) if len(times)>1 else 0.0

def run_batch():
    sizes = [(50,50), (100,50), (200,100)]  # (n,m)
    gens = {
        "random": lambda n,m: gen_random_matrix(n,m,0,1000),
        "sorted_rows": lambda n,m: gen_sorted_rows_matrix(n,m),
        "reverse_rows": lambda n,m: gen_reverse_rows_matrix(n,m)
    }
    results = {}
    for gen_name, gen_fn in gens.items():
        results[gen_name] = {}
        for n,m in sizes:
            results[gen_name][f"{n}x{m}"] = {}
            for alg in ALGORITHMS.keys():
                mean, stdev = measure(alg, gen_fn, n, m, runs=3)
                results[gen_name][f"{n}x{m}"][alg] = {"mean_s": mean, "stdev_s": stdev}
                print(f"{gen_name} {n}x{m} {alg}: {mean:.6f}s (sd {stdev:.6f})")
    # save results
    import json, os
    os.makedirs("results", exist_ok=True)
    with open("results/bench_results.json", "w") as f:
        json.dump(results, f, indent=2)
    return results

if __name__ == "__main__":
    res = run_batch()
    print("\\nDone.")
