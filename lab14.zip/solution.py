
"""
Лабораторная работа №14 — Инспекция кода модулей проекта
Реализация: Python 3
Задача:
 - даны двумерный массив n x m
 - отсортировать элементы каждой строки по возрастанию
 - затем отсортировать строки по возрастанию среднего арифметического элементов строки
 - реализовать несколько способов сортировки и сравнить их по времени

Файлы:
 - solution.py  (этот файл)
 - tests.py     (запуск тестов и сбор замеров)
"""

from typing import List, Callable, Tuple
import random, time, statistics, copy

# Sorting algorithms for a single list
def builtin_sort(row: List[int]) -> List[int]:
    return sorted(row)

def bubble_sort(row: List[int]) -> List[int]:
    a = row[:]
    n = len(a)
    for i in range(n):
        swapped = False
        for j in range(0, n-i-1):
            if a[j] > a[j+1]:
                a[j], a[j+1] = a[j+1], a[j]
                swapped = True
        if not swapped:
            break
    return a

def insertion_sort(row: List[int]) -> List[int]:
    a = row[:]
    for i in range(1, len(a)):
        key = a[i]
        j = i - 1
        while j >= 0 and a[j] > key:
            a[j+1] = a[j]
            j -= 1
        a[j+1] = key
    return a

def quicksort(row: List[int]) -> List[int]:
    # simple quicksort (not in-place)
    if len(row) <= 1:
        return row[:]
    pivot = row[len(row)//2]
    left = [x for x in row if x < pivot]
    middle = [x for x in row if x == pivot]
    right = [x for x in row if x > pivot]
    return quicksort(left) + middle + quicksort(right)

# High-level operations on matrix
def sort_rows(matrix: List[List[int]], row_sort_fn: Callable[[List[int]], List[int]]) -> List[List[int]]:
    return [row_sort_fn(r) for r in matrix]

def row_average(row: List[int]) -> float:
    return sum(row)/len(row) if row else 0.0

def sort_matrix_by_row_average(matrix: List[List[int]]) -> List[List[int]]:
    return sorted(matrix, key=row_average)

# Full pipeline: sort rows then sort matrix by averages
def full_sort_pipeline(matrix: List[List[int]], row_sort_fn: Callable[[List[int]], List[int]]) -> List[List[int]]:
    sorted_rows = sort_rows(matrix, row_sort_fn)
    return sort_matrix_by_row_average(sorted_rows)

# Helpers to generate test matrices
def gen_random_matrix(n:int, m:int, low:int=0, high:int=100) -> List[List[int]]:
    return [[random.randint(low, high) for _ in range(m)] for __ in range(n)]

def gen_sorted_rows_matrix(n:int, m:int) -> List[List[int]]:
    return [list(range(i, i+m)) for i in range(n)]

def gen_reverse_rows_matrix(n:int, m:int) -> List[List[int]]:
    return [list(range(m-i, 0, -1)) for i in range(n)]

# For basic correctness tests
def is_rows_sorted(matrix: List[List[int]]) -> bool:
    return all(all(row[i] <= row[i+1] for i in range(len(row)-1)) for row in matrix)

def is_matrix_sorted_by_average(matrix: List[List[int]]) -> bool:
    avgs = [row_average(r) for r in matrix]
    return all(avgs[i] <= avgs[i+1] for i in range(len(avgs)-1))

# Expose API for testing harness
ALGORITHMS = {
    "builtin": builtin_sort,
    "bubble": bubble_sort,
    "insertion": insertion_sort,
    "quicksort": quicksort
}

if __name__ == "__main__":
    # quick manual test
    mat = gen_random_matrix(5,6,0,50)
    print("Original:")
    for r in mat: print(r)
    out = full_sort_pipeline(mat, ALGORITHMS["builtin"])
    print("\nAfter:")
    for r in out: print(r)
